<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from demo2.steelthemes.com/cargohub/contact/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Feb 2018 08:47:31 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="pingback" href="../xmlrpc.php">

	<title>Contact &#8211; Phoenix</title>
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="CargoHub &raquo; Feed" href="../feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="CargoHub &raquo; Comments Feed" href="../comments/feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/demo2.steelthemes.com\/cargohub\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.8.5"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,56826,8203,55356,56819),0,0),c=j.toDataURL(),b!==c&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55358,56794,8205,9794,65039),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55358,56794,8203,9794,65039),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='../wp-content/plugins/contact-form-7/includes/css/styles20fd.css?ver=4.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='../wp-content/plugins/revslider/public/assets/css/settingsc225.css?ver=5.4.1' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='cargohub-fonts-css'  href='https://fonts.googleapis.com/css?family=Montserrat%3A400%2C400i%2C500%2C500i%2C600%2C600i%2C700%2C700i%7COpen+Sans%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C700%2C700i%2C800%2C800i&amp;subset=latin%2Clatin-ext&amp;ver=20161025' type='text/css' media='all' />
<link rel='stylesheet' id='factoryplus-icons-css'  href='../wp-content/themes/cargohub/css/factoryplus-icons79d4.css?ver=20161025' type='text/css' media='all' />
<link rel='stylesheet' id='flaticon-css'  href='../wp-content/themes/cargohub/css/flaticon5689.css?ver=20170425' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='../wp-content/themes/cargohub/css/bootstrap.min7433.css?ver=3.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css'  href='../wp-content/themes/cargohub/css/jquery.fancyboxd63f.css?ver=2.1.5' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='../wp-content/themes/cargohub/css/font-awesome.min4698.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='cargohub-css'  href='../wp-content/themes/cargohub/style79d4.css?ver=20161025' type='text/css' media='all' />
<style id='cargohub-inline-css' type='text/css'>
.header-title { background-image: url(../wp-content/uploads/sites/7/2017/07/page-header-bg.jpg); }.site-footer {background-color: #232951;}.footer-widgets {background-color: #0c1239;background-image: url(http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/footer-bg.jpg);}	.fh-latest-post .item-latest-post .entry-thumbnail a,
	.fh-service-box.style-1
	.fh-service-box.style-1 a
	{ cursor: url( ../wp-content/themes/cargohub/img/cursor.png), auto; }	.fh-latest-post.carousel .owl-nav div,
	.fh-team .owl-carousel .owl-nav div,
	.fh-icon-box,
	.fh-icon-box a
	{ cursor: url( ../wp-content/themes/cargohub/img/cursor2.png), auto; }
</style>
<link rel='stylesheet' id='cargohub-style-switcher-css'  href='../wp-content/plugins/cargohub-style-switcher/css/switcher341d.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='cargohub-color-switcher-css'  href='../wp-content/plugins/cargohub-style-switcher/css/default341d.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='../wp-content/plugins/js_composer/assets/css/js_composer.min7661.css?ver=5.4.2' type='text/css' media='all' />
<script type='text/javascript' src='../wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='../wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<script type='text/javascript' src='../wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.minc225.js?ver=5.4.1'></script>
<script type='text/javascript' src='../wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.minc225.js?ver=5.4.1'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://demo2.steelthemes.com/cargohub/wp-content/themes/cargohub/js/html5shiv.min.js?ver=3.7.2'></script>
<![endif]-->
<!--[if lt IE 9]>
<script type='text/javascript' src='http://demo2.steelthemes.com/cargohub/wp-content/themes/cargohub/js/respond.min.js?ver=1.4.2'></script>
<![endif]-->
<link rel='https://api.w.org/' href='../wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="../xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.8.5" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='../index5831.html?p=19' />
<link rel="alternate" type="application/json+oembed" href="../wp-json/oembed/1.0/embed8965.json?url=http%3A%2F%2Fdemo2.steelthemes.com%2Fcargohub%2Fcontact%2F" />
<link rel="alternate" type="text/xml+oembed" href="../wp-json/oembed/1.0/embed94f2?url=http%3A%2F%2Fdemo2.steelthemes.com%2Fcargohub%2Fcontact%2F&amp;format=xml" />
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://demo2.steelthemes.com/cargohub/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.1 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="../wp-content/uploads/sites/7/2017/08/favicon.png" sizes="32x32" />
<link rel="icon" href="../wp-content/uploads/sites/7/2017/08/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="../wp-content/uploads/sites/7/2017/08/favicon.png" />
<meta name="msapplication-TileImage" content="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/08/favicon.png" />
		<style type="text/css" id="wp-custom-css">
			/*
You can add your own CSS here.

Click the help icon above to learn more.
*/
#text-4 {
	padding-left: 0;
}

.header-v1 .cargo-office-location-widget,
.header-v2 .cargo-office-location-widget{
	padding-left: 0;
}

.header-v4 #cargohub-social-links-widget-2 {
	padding-right: 0;
}

.topbar .cargo-search-widget {
	padding-right: 0;
}

.header-v3 .footer-widgets .cargohub-social-links-widget,
.header-v4 .footer-widgets .cargohub-social-links-widget {
	padding-top: 20px;
	border-top: 1px solid rgba( 255, 255, 255, 0.1 );
}		</style>
	<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1500720290348{padding-top: 70px !important;padding-bottom: 35px !important;}.vc_custom_1500714649799{padding-top: 70px !important;padding-bottom: 80px !important;background-color: #f7f7f7 !important;}.vc_custom_1503374718925{padding-top: 10px !important;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="page-template page-template-template-fullwidth page-template-template-fullwidth-php page page-id-19  no-sidebar header-transparent header-sticky hide-topbar-mobile error404-no-bg blog-classic header-v1 wpb-js-composer js-comp-ver-5.4.2 vc_responsive">
<div id="page" class="hfeed site">

	<div id="fh-header-minimized" class="fh-header-minimized fh-header-v1"></div>	<div id="topbar" class="topbar">
		<div class="container">
			
			<div class="topbar-left topbar-widgets text-left">
				<div id="text-14" class="widget widget_text">			<div class="textwidget"><div class="topbar-contact"><i class="flaticon-cup "></i>World Wide Movers</div>
</div>
		</div><div id="text-13" class="widget widget_text">			<div class="textwidget"><div class="topbar-contact"><i class="flaticon-office "></i> World Wide Relocation Services</div>
</div>
		</div><div id="cargo-office-location-widget-2" class="widget cargo-office-location-widget"><div class="office-location clearfix"><div class="office-switcher"><i class="flaticon-globe "></i><a class="current-office" href="#"></a><ul><li class="location" data-tab="cargohub-office-1">Dubai Office</li></ul></div><ul class="office-1 topbar-office" id="cargohub-office-1"><li class="phone"><i class="flaticon-telephone" aria-hidden="true"></i>Phone +971 4 344 1516</li><li class="email"><i class="flaticon-web" aria-hidden="true"></i>info@phoenixmovers.ae</li><li class="address"><i class="flaticon-pin" aria-hidden="true"></i>Phoenix worldwidemovers, Dubai, UAE</li></ul></div></div>			</div>

						
			<div class="topbar-right topbar-widgets text-right">
				<div id="cargohub-social-links-widget-2" class="widget cargohub-social-links-widget"><div class="list-social style-1"><a href="#" class="share-facebook tooltip-enable social" rel="nofollow" title="Facebook" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" class="share-twitter tooltip-enable social" rel="nofollow" title="Twitter" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" class="share-google-plus tooltip-enable social" rel="nofollow" title="Google Plus" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-google-plus"></i></a><a href="#" class="share-skype tooltip-enable social" rel="nofollow" title="Skype" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-skype"></i></a><a href="#" class="share-youtube tooltip-enable social" rel="nofollow" title="Youtube" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-youtube"></i></a></div></div><div id="cargo-search-widget-3" class="widget cargo-search-widget"><div class="topbar-search topbar-search-1">
				<a href="#" class="toggle-search" id="toggle-search"><i class="fa fa-search" aria-hidden="true"></i></a>
				<form method="get" class="search-form" action="http://demo2.steelthemes.com/cargohub/">
					<i class="fa fa-search" aria-hidden="true"></i>
					<input type="search" class="search-field" placeholder="Search..." value="" name="s">
					<input type="submit" class="search-submit" value="Search">
				</form>
			</div></div><div id="cargo-search-widget-2" class="widget cargo-search-widget"><div class="topbar-search topbar-search-2">
				
				<form method="get" class="search-form" action="http://demo2.steelthemes.com/cargohub/">
					<i class="fa fa-search" aria-hidden="true"></i>
					<input type="search" class="search-field" placeholder="Search..." value="" name="s">
					<input type="submit" class="search-submit" value="Search">
				</form>
			</div></div>			</div>

					</div>
	</div>
	
	<header id="masthead" class="site-header clearfix">
		
<div class="header-main clearfix">
	<div class="container mobile_relative">
		<div class="row">
			<div class="site-logo col-md-3 col-sm-6 col-xs-6">
					<a href="../index.html" class="logo">
		<img src="../wp-content/themes/cargohub/img/logo-light.png" alt="CargoHub" class="logo-light show-logo">
		<img src="../wp-content/themes/cargohub/img/logo.png" alt="CargoHub" class="logo-dark hide-logo">
	</a>
<p class="site-title"><a href="../index.html" rel="home">Phoenix</a></p><h2 class="site-description">world wide movers</h2>
			</div>
			<div class="site-menu col-md-9 col-sm-6 col-xs-6">
				<nav id="site-navigation" class="main-nav primary-nav nav">
					<ul id="primary-menu" class="menu"><li id="menu-item-1738" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home  menu-item-1738"><a href="../index.html">Home</a>

</li>
<li id="menu-item-1945" class="menu-item menu-item-type-post_type menu-item-object-page page_item page-item-27  menu-item-has-children menu-item-1945"><a href="../services/">Services</a>
<ul  class="sub-menu">
	<li id="menu-item-1946" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1946"><a href="../services/#gotodomestic">Domestic Removal</a></li>
	<li id="menu-item-1947" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1947"><a href="../services/#gotointernational">International Removal</a></li>
	<li id="menu-item-1948" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1948"><a href="../services/#gotooffice">Office Removal</a></li>
	<li id="menu-item-1949" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1949"><a href="../services/#gotooffice">Storage Solutions</a></li>
	
</ul>
</li>
<li id="menu-item-1750" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1750"><a href="../testimonials/">TESTIMONIALS</a>

</li>
<li id="menu-item-1944" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1944"><a href="../gallery/index9ec3.html?p_style=4">Gallery</a>

</li>
<li id="menu-item-1752" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-1752"><a href="../moving-tips/">Moving Tips</a>

</li>

<li id="menu-item-1741" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item  current_page_item menu-item-1741"><a href="../contact/">Contact</a></li>

<li class="extra-menu-item menu-item-button-link">
						<a href="../request-a-quote/" class="fh-btn btn">Get A Quote</a>
					</li></ul>				</nav>
			</div>
		</div>
		<a href="#" class="navbar-toggle">
				<span class="navbar-icon">
					<span class="navbars-line"></span>
				</span>
			</a>	</div>
</div>

	</header><!-- #masthead -->

	
<div class="page-header title-area">
	<div class="header-title ">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<h1 class="page-title">Contact</h1>				</div>
			</div>
		</div>
	</div>
	<div class="breadcrumb-area">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-sm-12 col-xs-12 site-breadcrumb">
					<nav class="breadcrumb"><span itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
				<a class="home" href="../index.html" itemprop="url"><span itemprop="title">Home</span></a>
			</span><i class="fa fa-angle-right" aria-hidden="true"></i>
		<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
			<span itemprop="title">Contact</span>
		</span>
	</nav>				</div>
				<div class="col-md-4 col-sm-12 col-xs-12 site-social-share">
									</div>
			</div>
		</div>
	</div>
</div>
	<div id="content" class="site-content">
		
		<div class="container-fluid">
			<div class="row">

<div class="vc_row wpb_row vc_row-fluid vc_custom_1500720290348"><div class="container"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-8 vc_col-md-8"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="fh-section-title clearfix  text-left version-dark"><h2 style="font-size: 26px">Contact Details</h2></div><div class="vc_empty_space"   style="height: 35px" ><span class="vc_empty_space_inner"></span></div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p>If you have any questions about what we offer for consumers or for business, you can always email us or call us via the below details. We’ll reply within 24 hours.</p>

		</div>
	</div>
<div class="vc_empty_space"   style="height: 35px" ><span class="vc_empty_space_inner"></span></div>
<div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="fh-contact-box type-address "><i class="flaticon-pin"></i><h4 class="box-title">Visit our office</h4><div class="desc"><p>Phoenix Worldwide Movers LLC
Bin Bishar Building, PO Box 85268, Abu hail road <BR/> Dubai - UAE
  </p>
</div></div><div class="fh-contact-box type-email "><i class="flaticon-business"></i><h4 class="box-title">Mail Us at</h4><div class="desc"><p>info@phoenixmovers.ae<br />
Operations@phoenixmovers.ae</p>
</div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="fh-contact-box type-phone "><i class="flaticon-phone-call "></i><h4 class="box-title">Call us on</h4><div class="desc"><p>Phone +971 4 344 1516 <br /> Fax +971 4 266 0634 <br/>
</p>
</div></div><div class="fh-contact-box type-social "><i class="flaticon-share"></i><h4 class="box-title">We are social</h4><ul class="clearfix"><li class="facebook">
					<a href="#" target="_blank">
						<i class="fa fa-facebook"></i>
					</a>
				</li><li class="twitter">
					<a href="#" target="_blank">
						<i class="fa fa-twitter"></i>
					</a>
				</li><li class="googleplus">
					<a href="#" target="_blank">
						<i class="fa fa-google-plus"></i>
					</a>
				</li><li class="pinterest">
					<a href="#" target="_blank">
						<i class="fa fa-pinterest"></i>
					</a>
				</li><li class="linkedin">
					<a href="#" target="_blank">
						<i class="fa fa-linkedin"></i>
					</a>
				</li></ul></div></div></div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4 vc_col-md-4"><div class="vc_column-inner vc_custom_1503374718925"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<div class="opening-hours vc_opening-hours">
<h3>WORKING HOURS</h3>
<p>Pleasure and praising pain was born and will give you a complete happiness.</p>
<ul>
<li>Saturday <span class="hour">8:30 am – 5.00 pm</span></li>
<li>Sunday <span class="hour">8:30 am – 5.00 pm</span></li>
<li>Monday<span class="hour">8:30 am – 5.00 pm</span></li>
<li>Tuesday<span class="hour">8:30 am – 5.00 pm</span></li>
<li>Wednesday <span class="hour">8:30 am – 5.00 pm</span></li>
<li>Thursday<span class="hour">8:30 am – 5.00 pm</span></li>
<li>Friday<span class="hour main-color">Closed</span></li>
</ul>
</div>

		</div>
	</div>
</div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1500714649799 vc_row-has-fill"><div class="container"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="fh-section-title clearfix  text-center version-dark"><h2 style="font-size: 26px">Leave Your Message</h2></div><div class="vc_empty_space"   style="height: 30px" ><span class="vc_empty_space_inner"></span></div>

	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<div style="width: 70%; margin: 0 auto; text-align: center; font-weight: 300;">If you have any questions about the services we provide simply use the form below. We try and respond to all<br />
queries and comments within 24 hours.</div>

		</div>
	</div>
<div class="vc_empty_space"   style="height: 50px" ><span class="vc_empty_space_inner"></span></div>
<div role="form" class="wpcf7" id="wpcf7-f1615-p19-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="sendmail.php" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="1615" />
<input type="hidden" name="_wpcf7_version" value="4.9.2" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f1615-p19-o1" />
<input type="hidden" name="_wpcf7_container_post" value="19" />
</div>
<div class="fh-form fh-form-3">
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-12">
<p class="field"><span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name*" /></span></p>
<p class="field"><span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email Address*" /></span></p>
<p class="field"><span class="wpcf7-form-control-wrap your-phone"><input type="text" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Phone" /></span></p>
<p class="field"><span class="wpcf7-form-control-wrap subject"><input type="text" name="subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Subject" /></span></p>
</div>
<div class="col-md-6 col-sm-6 col-xs-12">
<p class="field single-field"><span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Your Message..."></textarea></span></p>
</div>
<div class="col-md-12 col-sm-12 col-xs-12">
<p class="field submit"><input type="submit" value="Submit" Name ="submit" class="wpcf7-form-control wpcf7-submit fh-btn" /></p>
</div></div>
</div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form>
                
                
                
                
                
                </div></div></div></div></div></div></div><div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding"><div class="container-fluid"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="fh-map-shortcode fh-map-style-2 "><iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d11512.192947578762!2d55.34129237531905!3d25.28026547612342!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x3e5f5cf3458e41d3%3A0xb51f7aed919af8f4!2sphoenix+world+wide+movers!3m2!1d25.279859!2d55.344673!5e0!3m2!1sen!2sae!4v1517991772651" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div></div></div></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div>

			</div> <!-- .row -->
		</div> <!-- .container -->
	</div><!-- #content -->

			<div id="footer-widgets" class="footer-widgets widgets-area">
					<div class="contact-widget">
			<div class="container">
				<div class="row">
					<div class="contact col-md-3 col-xs-12 col-sm-12"><a href="index.html" class="footer-logo"><img src="../wp-content/uploads/sites/7/2017/09/logo-light.png" alt="Footer Logo"></a></div><div class="contact col-md-3 col-xs-12 col-sm-12"><i class="flaticon-signs"></i>
<p>Phoenix worldwide movers,</p>
<h4>Dubai, UAE</h4></div><div class="contact col-md-3 col-xs-12 col-sm-12"><i class="flaticon-phone-call "></i><p>Telephone Number :</p>
<h4>+971 4 344 1516</h4></div><div class="contact col-md-3 col-xs-12 col-sm-12"><i class="flaticon-clock-1"></i>
<p>Opening Hours :</p>
<h4>SAT – THU: 8 AM – 5.30 PM</h4></div>				</div>
			</div>
		</div>
							<div class="footer-sidebars">
			<div class="container">
				<div class="row">
											<div class="footer-sidebar footer-1 col-xs-12 col-sm-6 col-md-3">
							<div id="text-11" class="widget widget_text"><h4 class="widget-title">About Phoenix</h4>			<div class="textwidget"><p style="padding-bottom: 15px;">Phoenix Worldwide Movers is a UAE based organization specialized in Door to Door domestic and International Moving activities.</p>
</div>
		</div><div id="cargohub-social-links-widget-4" class="widget cargohub-social-links-widget"><div class="list-social style-1"><a href="#" class="share-facebook tooltip-enable social" rel="nofollow" title="Facebook" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" class="share-twitter tooltip-enable social" rel="nofollow" title="Twitter" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" class="share-google-plus tooltip-enable social" rel="nofollow" title="Google Plus" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-google-plus"></i></a><a href="#" class="share-linkedin tooltip-enable social" rel="nofollow" title="Linkedin" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-linkedin"></i></a></div></div><div id="cargohub-social-links-widget-3" class="widget cargohub-social-links-widget"><div class="list-social style-2"><a href="#" class="share-facebook tooltip-enable social" rel="nofollow" title="Facebook" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" class="share-twitter tooltip-enable social" rel="nofollow" title="Twitter" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" class="share-google-plus tooltip-enable social" rel="nofollow" title="Google Plus" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-google-plus"></i></a><a href="#" class="share-linkedin tooltip-enable social" rel="nofollow" title="Linkedin" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-linkedin"></i></a></div></div>						</div>
											<div class="footer-sidebar footer-2 col-xs-12 col-sm-6 col-md-3">
							<div id="nav_menu-2" class="widget widget_nav_menu"><h4 class="widget-title">Useful Links</h4><div class="menu-service-menu-container"><ul id="menu-service-menu" class="menu"><li id="menu-item-1971" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1971"><a href="../services/">Services</a></li>
<li id="menu-item-1965" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1965"><a href="../testimonials/">Testimonials</a></li>
<li id="menu-item-1966" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1966"><a href="../gallery/index9ec3.html?p_style=4">Gallery</a></li>
<li id="menu-item-1970" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1970"><a href="../moving-tips/">Moving Tips</a></li>
<li id="menu-item-1967" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1967"><a href="../contact/">Contact</a></li>
<li id="menu-item-1968" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1968"><a href="../request-a-quote/">Get A Quote</a></li>
</ul></div></div>						</div>
											<div class="footer-sidebar footer-3 col-xs-12 col-sm-6 col-md-3">
							<div id="latest-project-widget-2" class="widget latest-project-widget"><h4 class="widget-title">Photo gallery</h4><div class="latest-project-list clearfix">			<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="../gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="../wp-content/uploads/sites/7/2017/07/transport_03-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/transport_03-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/transport_03-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/transport_03-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="../gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="../wp-content/uploads/sites/7/2017/07/shutterstock_95914933-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_95914933-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_95914933-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_95914933-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="../gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="../wp-content/uploads/sites/7/2017/07/shutterstock_299049458-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_299049458-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_299049458-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_299049458-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="../gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="../wp-content/uploads/sites/7/2017/07/shutterstock_124661011-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_124661011-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_124661011-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_124661011-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="../gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="../wp-content/uploads/sites/7/2017/07/shutterstock_142307377-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_142307377-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_142307377-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_142307377-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="../gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="../wp-content/uploads/sites/7/2017/07/shutterstock_301382870-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_301382870-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_301382870-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_301382870-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
		</div></div>						</div>
											<div class="footer-sidebar footer-4 col-xs-12 col-sm-6 col-md-3">
							<div id="mc4wp_form_widget-2" class="widget widget_mc4wp_form_widget"><h4 class="widget-title">Our Newsletter</h4><script type="text/javascript">(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();
</script><!-- MailChimp for WordPress v4.1.14 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-1753" method="post" data-id="1753" data-name="Subscribe Form" ><div class="mc4wp-form-fields"><div class="fh-form-field">
  <p>
    Sign up today for tips and latest news and exclusive special offers.
  </p>
  <div class="subscribe">
	<input type="email" name="EMAIL" placeholder="Enter Your Email" required />
  	<input type="submit" value="Sign Up" />
  </div>
</div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1517819429" /><input type="hidden" name="_mc4wp_form_id" value="1753" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /></div><div class="mc4wp-response"></div></form><!-- / MailChimp for WordPress Plugin --></div><div id="text-12" class="widget widget_text">			<div class="textwidget"><p>We don’t do spam and Your mail id very confidential.</p>
</div>
		</div>						</div>
					
				</div>
			</div>
		</div>
				</div>
	
	<footer id="colophon" class="site-footer">
			<div class="container">
		<div class="row">
			<div class="footer-copyright col-md-6 col-sm-12 col-sx-12">
				<div class="site-info">
					Copyright @ 2018 <a href="mailto:sevenone4advertising@gmail.com">SevenOne4</a>, All Right Reserved				</div><!-- .site-info -->
			</div>
			<div class="col-md-6 col-sm-12 col-xs-12 text-right footer-text">
				<a href="#">Phoenix Dubai</a>			</div>
		</div>
	</div>
		</footer><!-- #colophon -->

	</div><!-- #page -->

	<div class="primary-mobile-nav" id="primary-mobile-nav" role="navigation">
		<a href="#" class="close-canvas-mobile-panel">
			&#215;
		</a>
       <ul id="menu-primary-menu" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-1738"><a href="../index.html">Home</a>

</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1945"><a href="../services/index.html">Services</a>
<ul  class="sub-menu">
	<li id="menu-item-1946" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1946"><a href="../services/#gotodomestic">Domestic Removal</a></li>
	<li id="menu-item-1947" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1947"><a href="../services/#gotointernational">International Removal</a></li>
	<li id="menu-item-1948" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1948"><a href="../services/#gotooffice">Office Removal</a></li>
	<li id="menu-item-1949" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1949"><a href="../services/#gotooffice">Storage Solutions</a></li>
	
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-1750"><a href="../testimonials/">Testimonials</a>

</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1944"><a href="../gallery/index9ec3.html?p_style=4">Gallery</a>

</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1752"><a href="../moving-tips/">Moving Tips</a>

</li>

<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1741"><a href="../contact">Contact</a></li>
<li class="extra-menu-item menu-item-button-link">
						<a href="../request-a-quote/" class="fh-btn btn">Get A Quote</a>
					</li></ul>	</div>
		<div id="off-canvas-layer" class="off-canvas-layer"></div>
			<a id="scroll-top" class="backtotop" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>
	<script>if ( typeof google !== "object" || typeof google.maps !== "object" )
				document.write('<script src="//maps.google.com/maps/api/js?sensor=false&key=AIzaSyA7_-dqBdPznv5nSNhB9pYhB4zj1e9ZV7s"><\/script>')</script>
		

		<script type="text/javascript">(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script><script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/demo2.steelthemes.com\/cargohub\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='../wp-content/plugins/contact-form-7/includes/js/scripts20fd.js?ver=4.9.2'></script>
<script type='text/javascript' src='../wp-content/themes/cargohub/js/plugins.min79d4.js?ver=20161025'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var cargohub = {"cargohub_back":"Back","direction":""};
var cargohubShortCode = {"map":{"fh_map_5a7816eac0199":{"style":"2","color":"#ff0000","type":"normal","lat":[51.5074464,51.5061009],"lng":[-0.0769224,-0.0895958],"zoom":13,"marker":"http:\/\/demo2.steelthemes.com\/cargohub\/wp-content\/uploads\/sites\/7\/2017\/07\/maker.png","height":450,"info":["Traitors' Gate, London","Southwark Cathedral, London"],"number":2}}};
/* ]]> */
</script>
<script type='text/javascript' src='../wp-content/themes/cargohub/js/scripts.min79d4.js?ver=20161025'></script>
<script type='text/javascript' src='../wp-content/plugins/cargohub-style-switcher/js/switcher5793.js?ver=20170810'></script>
<script type='text/javascript' src='../wp-includes/js/wp-embed.min341d.js?ver=4.8.5'></script>
<script type='text/javascript' src='../../../ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfontd92a.js?ver=3.0.22'></script>
<script type='text/javascript' src='../wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min7661.js?ver=5.4.2'></script>
<script type='text/javascript' src='../wp-content/plugins/cargohub-vc-addons/assets/js/jquery.tabs8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='../wp-content/plugins/cargohub-vc-addons/assets/js/owl.carousel3601.js?ver=2.2.0'></script>
<script type='text/javascript' src='../wp-content/plugins/cargohub-vc-addons/assets/js/frontend6a0c.js?ver=20170808'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */
</script>
<script type='text/javascript' src='../wp-content/plugins/mailchimp-for-wp/assets/js/forms-api.min79ab.js?ver=4.1.14'></script>
<!--[if lte IE 9]>
<script type='text/javascript' src='http://demo2.steelthemes.com/cargohub/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.1.14'></script>
<![endif]-->

</body>

<!-- Mirrored from demo2.steelthemes.com/cargohub/contact/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Feb 2018 08:47:39 GMT -->
</html>
