<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from demo2.steelthemes.com/cargohub/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Feb 2018 08:30:28 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="pingback" href="xmlrpc.php">

	<title>Phoenix &#8211; World Wide Movers</title>
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="CargoHub &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="CargoHub &raquo; Comments Feed" href="comments/feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/demo2.steelthemes.com\/cargohub\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.8.5"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,56826,8203,55356,56819),0,0),c=j.toDataURL(),b!==c&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55358,56794,8205,9794,65039),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55358,56794,8203,9794,65039),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/styles20fd.css?ver=4.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='wp-content/plugins/revslider/public/assets/css/settingsc225.css?ver=5.4.1' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='cargohub-fonts-css'  href='https://fonts.googleapis.com/css?family=Montserrat%3A400%2C400i%2C500%2C500i%2C600%2C600i%2C700%2C700i%7COpen+Sans%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C700%2C700i%2C800%2C800i&amp;subset=latin%2Clatin-ext&amp;ver=20161025' type='text/css' media='all' />
<link rel='stylesheet' id='factoryplus-icons-css'  href='wp-content/themes/cargohub/css/factoryplus-icons79d4.css?ver=20161025' type='text/css' media='all' />
<link rel='stylesheet' id='flaticon-css'  href='wp-content/themes/cargohub/css/flaticon5689.css?ver=20170425' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='wp-content/themes/cargohub/css/bootstrap.min7433.css?ver=3.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css'  href='wp-content/themes/cargohub/css/jquery.fancyboxd63f.css?ver=2.1.5' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='wp-content/themes/cargohub/css/font-awesome.min4698.css?ver=4.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='cargohub-css'  href='wp-content/themes/cargohub/style79d4.css?ver=20161025' type='text/css' media='all' />
<style id='cargohub-inline-css' type='text/css'>
.site-footer {background-color: #232951;}.footer-widgets {background-color: #0c1239;background-image: url(wp-content/uploads/sites/7/2017/07/footer-bg.jpg);}	.fh-latest-post .item-latest-post .entry-thumbnail a,
	.fh-service-box.style-1
	.fh-service-box.style-1 a
	{ cursor: url( wp-content/themes/cargohub/img/cursor.png), auto; }	.fh-latest-post.carousel .owl-nav div,
	.fh-team .owl-carousel .owl-nav div,
	.fh-icon-box,
	.fh-icon-box a
	{ cursor: url( wp-content/themes/cargohub/img/cursor2.png), auto; }
</style>
<link rel='stylesheet' id='cargohub-style-switcher-css'  href='wp-content/plugins/cargohub-style-switcher/css/switcher341d.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='cargohub-color-switcher-css'  href='wp-content/plugins/cargohub-style-switcher/css/default341d.css?ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='wp-content/plugins/js_composer/assets/css/js_composer.min7661.css?ver=5.4.2' type='text/css' media='all' />
<script type='text/javascript' src='wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.minc225.js?ver=5.4.1'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.minc225.js?ver=5.4.1'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://demo2.steelthemes.com/cargohub/wp-content/themes/cargohub/js/html5shiv.min.js?ver=3.7.2'></script>
<![endif]-->
<!--[if lt IE 9]>
<script type='text/javascript' src='http://demo2.steelthemes.com/cargohub/wp-content/themes/cargohub/js/respond.min.js?ver=1.4.2'></script>
<![endif]-->
<link rel='https://api.w.org/' href='wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.8.5" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='index.html' />
<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed15ec.json?url=http%3A%2F%2Fdemo2.steelthemes.com%2Fcargohub%2F" />
<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embedbdd1?url=http%3A%2F%2Fdemo2.steelthemes.com%2Fcargohub%2F&amp;format=xml" />
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://demo2.steelthemes.com/cargohub/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.1 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="wp-content/uploads/sites/7/2017/08/favicon.png" sizes="32x32" />
<link rel="icon" href="wp-content/uploads/sites/7/2017/08/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="wp-content/uploads/sites/7/2017/08/favicon.png" />
<meta name="msapplication-TileImage" content="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/08/favicon.png" />
		<style type="text/css" id="wp-custom-css">
			/*
You can add your own CSS here.

Click the help icon above to learn more.
*/
#text-4 {
	padding-left: 0;
}

.header-v1 .cargo-office-location-widget,
.header-v2 .cargo-office-location-widget{
	padding-left: 0;
}

.header-v4 #cargohub-social-links-widget-2 {
	padding-right: 0;
}

.topbar .cargo-search-widget {
	padding-right: 0;
}

.header-v3 .footer-widgets .cargohub-social-links-widget,
.header-v4 .footer-widgets .cargohub-social-links-widget {
	padding-top: 20px;
	border-top: 1px solid rgba( 255, 255, 255, 0.1 );
}		</style>
	<style type="text/css" data-type="vc_custom-css">.fh-icon-box.style-2 .fh-icon {
    background-color: #fff;
}


@media (max-width: 600px) {
    .count-title {
        padding: 0 !important;
        font-size: 44px !important;
    }
}

@media (max-width: 768px) {
    .intro-hp1 {
        width: 100% !important;
    }
}

</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1499761006039{padding-top: 65px !important;padding-bottom: 50px !important;}.vc_custom_1499827444315{padding-top: 70px !important;padding-bottom: 50px !important;background-color: #0c1239 !important;}.vc_custom_1502443146147{padding-top: 110px !important;padding-bottom: 110px !important;background-image: url(wp-content/uploads/sites/7/2017/07/count-bg-16957.jpg?id=1997) !important;}.vc_custom_1502336598998{background-image: url(http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/Untitled-1.jpg?id=1760) !important;}.vc_custom_1502442889699{padding-top: 40px !important;padding-bottom: 40px !important;}.vc_custom_1499848637052{padding-top: 70px !important;padding-bottom: 50px !important;}.vc_custom_1503374140096{padding-top: 20px !important;padding-bottom: 55px !important;}.vc_custom_1499827458962{padding-bottom: 50px !important;}.vc_custom_1503374258167{border-left-width: 2px !important;padding-left: 25px !important;border-left-color: #ff8000 !important;border-left-style: solid !important;}.vc_custom_1499846353092{padding-bottom: 40px !important;}.vc_custom_1503374316094{padding-bottom: 30px !important;}.vc_custom_1503374338127{padding-right: 30px !important;padding-left: 30px !important;background-color: #f7f7f7 !important;}.vc_custom_1499847750771{padding-top: 70px !important;}.vc_custom_1500447037234{margin-top: -60px !important;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="home page-template page-template-template-homepage page-template-template-homepage-php page page-id-11  no-sidebar header-transparent header-sticky hide-topbar-mobile error404-no-bg blog-classic header-v1 wpb-js-composer js-comp-ver-5.4.2 vc_responsive">
<div id="page" class="hfeed site">

	<div id="fh-header-minimized" class="fh-header-minimized fh-header-v1"></div>	
	
	<header id="masthead" class="site-header clearfix">
		
<div class="header-main clearfix">
	<div class="container mobile_relative">
		<div class="row">
			<div class="site-logo col-md-3 col-sm-6 col-xs-6">
					<a href="index.html" class="logo">
		<img src="wp-content/themes/cargohub/img/logo-light.png" alt="CargoHub" class="logo-light show-logo">
		<img src="wp-content/themes/cargohub/img/logo.png" alt="CargoHub" class="logo-dark hide-logo">
	</a>
<h1 class="site-title"><a href="index.html" rel="home">Phoenix</a></h1><h2 class="site-description">World Wide Movers</h2>
			</div>
			<div class="site-menu col-md-9 col-sm-6 col-xs-6">
				<nav id="site-navigation" class="main-nav primary-nav nav">
					<ul id="primary-menu" class="menu"><li id="menu-item-1738" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-1738"><a href="index.html">Home</a>
                        
                        
                   
                        

</li>  
<li id="menu-item-1945" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1945"><a href="services/index.html">Services</a>
<ul  class="sub-menu">
	<li id="menu-item-1946" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1946"><a href="../services/#gotodomestic">Domestic Removal</a></li>
	<li id="menu-item-1947" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1947"><a href="../services/#gotointernational">International Removal</a></li>
	<li id="menu-item-1948" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1948"><a href="../services/#gotooffice">Office Removal</a></li>
	<li id="menu-item-1949" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1949"><a href="../services/#gotooffice">Storage Solutions</a></li>
	
</ul>
</li>
<li id="menu-item-1750" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1750"><a href="testimonials/">Testimonials</a>

</li>
<li id="menu-item-1944" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1944"><a href="gallery/index9ec3.html?p_style=4">Gallery</a>

</li>
<li id="menu-item-1752" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-1752"><a href="moving-tips/">Moving Tips</a>

</li>

<li id="menu-item-1741" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1741"><a href="contact/">Contact</a></li>
<li class="extra-menu-item menu-item-button-link">
						<a href="request-a-quote/" class="fh-btn btn">Get A Quote</a>
                        </li></ul>		</nav>
			</div>
		</div>
		<a href="#" class="navbar-toggle">
				<span class="navbar-icon">
					<span class="navbars-line"></span>
				</span>
			</a>	</div>
</div>

	</header><!-- #masthead -->

	
	<div id="content" class="site-content">
		
		<div class="container-fluid">
			<div class="row">

<div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding"><div class="container-fluid"><div class="vc_row-full-width vc_clearfix"></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1502336598998 vc_row-has-fill"><div class="container"></div></div><div class="vc_row-full-width vc_clearfix"> </div><div class="vc_row wpb_row vc_row-fluid vc_custom_1499848637052"><div class="container"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><span class='main-color'></span> 		</div></div></div></div>

			</div> <!-- .row -->
		</div> <!-- .container -->
	</div><!-- #content -->

                
                <div id="primary" class="content-area">
		<main id="main" class="site-main">

			<section class="error-404 not-found">
				<div class="container">
					
						
						
							<header align="center">
								<h1 class="page-title">404</h1>
								<p class="line-1">OOPPS! THE PAGE YOU WERE LOOKING FOR, COULDN&#039;T BE FOUND.</p>
								
							</header><!-- .page-header -->

							
						
					
				</div>
			</section><!-- .error-404 -->
		</main><!-- #main -->
	</div><!-- #primary -->

			</div> <!-- .row -->
		</div> <!-- .container -->
	</div><!-- #content -->
                
                
                
                
                
			<div id="footer-widgets" class="footer-widgets widgets-area">
					<div class="contact-widget">
			<div class="container">
				<div class="row">
					<div class="contact col-md-3 col-xs-12 col-sm-12"><a href="index.html" class="footer-logo"><img src="wp-content/uploads/sites/7/2017/09/logo-light.png" alt="Footer Logo"></a></div><div class="contact col-md-3 col-xs-12 col-sm-12"><i class="flaticon-signs"></i>
<p>Phoenix worldwide movers,</p>
<h4>Dubai, UAE</h4></div><div class="contact col-md-3 col-xs-12 col-sm-12"><i class="flaticon-phone-call "></i><p>Telephone Number :</p>
<h4>+971 4 344 1516</h4></div><div class="contact col-md-3 col-xs-12 col-sm-12"><i class="flaticon-clock-1"></i>
<p>Opening Hours :</p>
<h4>SAT – THU: 8 AM – 5.30 PM</h4></div>				</div>
			</div>
		</div>
							<div class="footer-sidebars">
			<div class="container">
				<div class="row">
											<div class="footer-sidebar footer-1 col-xs-12 col-sm-6 col-md-3">
							<div id="text-11" class="widget widget_text"><h4 class="widget-title">About Phoenix</h4>			<div class="textwidget"><p style="padding-bottom: 15px;">Phoenix Worldwide Movers is a UAE based organization specialized in Door to Door domestic and International Moving activities.</p>
</div>
		</div><div id="cargohub-social-links-widget-4" class="widget cargohub-social-links-widget"><div class="list-social style-1"><a href="#" class="share-facebook tooltip-enable social" rel="nofollow" title="Facebook" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" class="share-twitter tooltip-enable social" rel="nofollow" title="Twitter" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" class="share-google-plus tooltip-enable social" rel="nofollow" title="Google Plus" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-google-plus"></i></a><a href="#" class="share-linkedin tooltip-enable social" rel="nofollow" title="Linkedin" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-linkedin"></i></a></div></div><div id="cargohub-social-links-widget-3" class="widget cargohub-social-links-widget"><div class="list-social style-2"><a href="#" class="share-facebook tooltip-enable social" rel="nofollow" title="Facebook" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-facebook"></i></a><a href="#" class="share-twitter tooltip-enable social" rel="nofollow" title="Twitter" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-twitter"></i></a><a href="#" class="share-google-plus tooltip-enable social" rel="nofollow" title="Google Plus" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-google-plus"></i></a><a href="#" class="share-linkedin tooltip-enable social" rel="nofollow" title="Linkedin" data-toggle="tooltip" data-placement="top" target="_blank"><i class="fa fa-linkedin"></i></a></div></div>						</div>
											<div class="footer-sidebar footer-2 col-xs-12 col-sm-6 col-md-3">
							<div id="nav_menu-2" class="widget widget_nav_menu"><h4 class="widget-title">Useful Links</h4><div class="menu-service-menu-container"><ul id="menu-service-menu" class="menu"><li id="menu-item-1971" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1971"><a href="services/">Services</a></li>
<li id="menu-item-1965" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1965"><a href="testimonials/">Testimonials</a></li>
<li id="menu-item-1966" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1966"><a href="gallery/index9ec3.html?p_style=4">Gallery</a></li>
<li id="menu-item-1970" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1970"><a href="moving-tips/">Moving Tips</a></li>
<li id="menu-item-1967" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1967"><a href="contact/">Contact</a></li>
<li id="menu-item-1968" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1968"><a href="request-a-quote/">Get A Quote</a></li>
</ul></div></div>						</div>
                    
                    
                    
                    
                    
											<div class="footer-sidebar footer-3 col-xs-12 col-sm-6 col-md-3">
							<div id="latest-project-widget-2" class="widget latest-project-widget"><h4 class="widget-title">Photo gallery</h4><div class="latest-project-list clearfix">			<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="wp-content/uploads/sites/7/2017/07/transport_03-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/transport_03-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/transport_03-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/transport_03-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="wp-content/uploads/sites/7/2017/07/shutterstock_95914933-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_95914933-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_95914933-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_95914933-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="wp-content/uploads/sites/7/2017/07/shutterstock_299049458-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_299049458-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_299049458-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_299049458-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="wp-content/uploads/sites/7/2017/07/shutterstock_124661011-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_124661011-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_124661011-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_124661011-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="wp-content/uploads/sites/7/2017/07/shutterstock_142307377-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_142307377-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_142307377-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_142307377-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
					<div class="latest-project clearfix">
				
						<div class="fp-widget-thumb">
							<a class="widget-thumb" href="gallery/index9ec3.html?p_style=4"><i class="fa fa-link" aria-hidden="true"></i><img width="150" height="150" src="wp-content/uploads/sites/7/2017/07/shutterstock_301382870-150x150.jpg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" srcset="http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_301382870-150x150.jpg 150w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_301382870-75x75.jpg 75w, http://demo2.steelthemes.com/cargohub/wp-content/uploads/sites/7/2017/07/shutterstock_301382870-80x80.jpg 80w" sizes="(max-width: 150px) 100vw, 150px" /></a>
						</div>
									</div>
		</div></div>					</div>
											<div class="footer-sidebar footer-4 col-xs-12 col-sm-6 col-md-3">
							<div id="mc4wp_form_widget-2" class="widget widget_mc4wp_form_widget"><h4 class="widget-title">Our Newsletter</h4><script type="text/javascript">(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();
</script><!-- MailChimp for WordPress v4.1.14 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-1753" method="post" data-id="1753" data-name="Subscribe Form" ><div class="mc4wp-form-fields"><div class="fh-form-field">
  <p>
    Sign up today for tips and latest news and exclusive special offers.
  </p>
  <div class="subscribe">
	<input type="email" name="EMAIL" placeholder="Enter Your Email" required />
  	<input type="submit" value="Sign Up" />
  </div>
</div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1517819429" /><input type="hidden" name="_mc4wp_form_id" value="1753" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /></div><div class="mc4wp-response"></div></form><!-- / MailChimp for WordPress Plugin --></div><div id="text-12" class="widget widget_text">			<div class="textwidget"><p>We don’t do spam and Your mail id very confidential.</p>
</div>
		</div>						</div>
					
				</div>
			</div>
		</div>
				</div>
	
	<footer id="colophon" class="site-footer">
			<div class="container">
		<div class="row">
			<div class="footer-copyright col-md-6 col-sm-12 col-sx-12">
				<div class="site-info">
					Copyright @ 2018 <a href="mailto:sevenone4advertising@gmail.com">SevenOne4</a>, All Right Reserved				</div><!-- .site-info -->
			</div>
			<div class="col-md-6 col-sm-12 col-xs-12 text-right footer-text">
				<a href="#">Phoenix Dubai</a>			</div>
		</div>
	</div>
		</footer><!-- #colophon -->

	</div><!-- #page -->

	<div class="primary-mobile-nav" id="primary-mobile-nav" role="navigation">
		<a href="#" class="close-canvas-mobile-panel">
			&#215;
		</a>
		<ul id="menu-primary-menu" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-1738"><a href="index.html">Home</a>

</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1945"><a href="services/index.html">Services</a>
<ul  class="sub-menu">
	<li id="menu-item-1946" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1946"><a href="../services/#gotodomestic">Domestic Removal</a></li>
	<li id="menu-item-1947" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1947"><a href="../services/#gotointernational">International Removal</a></li>
	<li id="menu-item-1948" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1948"><a href="../services/#gotooffice">Office Removal</a></li>
	<li id="menu-item-1949" class="menu-item menu-item-type-post_type menu-item-object-service menu-item-1949"><a href="../services/#gotooffice">Storage Solutions</a></li>
	
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1750"><a href="/testimonials/">Testimonials</a>

</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1944"><a href="/gallery/index9ec3.html?p_style=4">Gallery</a>

</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1752"><a href="/moving-tips/">Moving Tips</a>

</li>

<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1741"><a href="contact/">Contact</a></li>
<li class="extra-menu-item menu-item-button-link">
						<a href="request-a-quote/" class="fh-btn btn">Get A Quote</a>
					</li></ul>	</div>
		<div id="off-canvas-layer" class="off-canvas-layer"></div>
			<a id="scroll-top" class="backtotop" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>
	
		

		<script type="text/javascript">(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script>		<script type="text/javascript">
			function revslider_showDoubleJqueryError(sliderID) {
				var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
				errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
				errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
				errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
				errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
					jQuery(sliderID).show().html(errorMessage);
			}
		</script>
		<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/demo2.steelthemes.com\/cargohub\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/contact-form-7/includes/js/scripts20fd.js?ver=4.9.2'></script>
<script type='text/javascript' src='wp-content/themes/cargohub/js/plugins.min79d4.js?ver=20161025'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var cargohub = {"cargohub_back":"Back","direction":""};
var cargohubShortCode = {"testimonial":{"testimonial-slider-5a7816250dcbb":{"nav":false,"dot":true,"autoplay":false,"autoplay_speed":0,"autoplay_timeout":0,"columns":"1"}},"post":{"post-slider-5a78162512d46":{"nav":true,"dot":false,"autoplay":false,"autoplay_speed":0,"autoplay_timeout":0,"is_carousel":1,"columns":"3"}}};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/themes/cargohub/js/scripts.min79d4.js?ver=20161025'></script>
<script type='text/javascript' src='wp-content/plugins/cargohub-style-switcher/js/switcher5793.js?ver=20170810'></script>
<script type='text/javascript' src='wp-includes/js/wp-embed.min341d.js?ver=4.8.5'></script>
<script type='text/javascript' src='../../ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfontd92a.js?ver=3.0.22'></script>
<script type='text/javascript' src='wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min7661.js?ver=5.4.2'></script>
<script type='text/javascript' src='wp-content/plugins/cargohub-vc-addons/assets/js/jquery.tabs8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='wp-content/plugins/cargohub-vc-addons/assets/js/owl.carousel3601.js?ver=2.2.0'></script>
<script type='text/javascript' src='wp-content/plugins/cargohub-vc-addons/assets/js/frontend6a0c.js?ver=20170808'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/mailchimp-for-wp/assets/js/forms-api.min79ab.js?ver=4.1.14'></script>
<!--[if lte IE 9]>
<script type='text/javascript' src='http://demo2.steelthemes.com/cargohub/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.1.14'></script>
<![endif]-->

</body>

<!-- Mirrored from demo2.steelthemes.com/cargohub/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Feb 2018 08:34:44 GMT -->
</html>
